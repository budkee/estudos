Considere que a seguinte rota...: 
---
# newsletter/nws_service.py | executor do serviço
---

---
... deverá ser executada uma vez ao dia utilizando a apschedule em flask, forneça uma solução que (i) considere sua implementação as seguintes classes e métodos...:
---
# newsletter/nws_service.py | executor do serviço
---


---

---
# newsletter/app.py | módulo principal
---

