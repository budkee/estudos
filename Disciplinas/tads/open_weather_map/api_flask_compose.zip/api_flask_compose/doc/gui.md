# Website UI

Submissão do serviço com a interface de interação com usuários.

Esta atividade é bônus e o principal requisito é a possibilidade de interação com o serviço por meio de uma aplicação web.

Espera-se que a mesma disponha, entre outros:

1. Possibilidade de listagem dos últimos dados
2. Gráfico que possibilite uma análise visual dos mesmos
3. [Página para inscrição, e remoção, para recebimento dos boletins](../flask/app/static/newsletter/newsletter.html)
