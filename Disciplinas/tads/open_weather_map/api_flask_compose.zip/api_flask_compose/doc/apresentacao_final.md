# Sobre a API | Apresentação Final

Nessa atividade as duplas deverão submeter uma [vídeo]() apresentação da aplicação abordando:

1. Detalhes de cada serviço (tecnologias, arquiteturas, princípios aplicados, implantação, etc.)

2. Processo de implantação da aplicação, mostrando todos os passos necessários para a implantação da mesma.

3. Funcionamento da aplicação (mostrando o funcionamento na prática)
