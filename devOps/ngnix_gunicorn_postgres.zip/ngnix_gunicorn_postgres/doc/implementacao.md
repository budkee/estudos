# Como implementar?

## Pré-requisitos

- Docker

## Passos

1. Acesse via CLI o diretório da aplicação e digite `docker compose up -d --build`.

