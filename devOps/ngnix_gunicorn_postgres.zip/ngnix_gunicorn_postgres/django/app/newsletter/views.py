from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import User
from .serializers import UserSerializer
from .services import UserService, DataService

class UserViewSet(viewsets.ViewSet):
    
    user_service = UserService()
    data_service = DataService()

    # ---------- Registrar um novo usuário:
    @action(detail=False, methods=['post'], url_path='register')
    def register(self, request):
        email = request.data.get('email')
        frequency = request.data.get('frequency')
        if not email or not frequency:
            return Response({"error": "Email and frequency are required"}, status=status.HTTP_400_BAD_REQUEST)
        
        user = self.user_service.register_user(email, frequency)
        serializer = UserSerializer(user)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    # ---------- Descadastrar um usuário:
    @action(detail=False, methods=['post'], url_path='unsubscribe')
    def unsubscribe(self, request):
        email = request.data.get('email')
        if not email:
            return Response({"error": "Email is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        success = self.user_service.unsubscribe_user(email)
        if success:
            return Response({"message": "User unsubscribed successfully"}, status=status.HTTP_200_OK)
        return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

    # ---------- Listar todos os usuários registrados:
    @action(detail=False, methods=['get'], url_path='list')
    def list_users(self, request):
        users = self.user_service.get_all_users()
        serializer = UserSerializer(users, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    # ---------- Enviar notificações aos usuários cadastrados:
    @action(detail=False, methods=['post'], url_path='send_notifications')
    def send_notifications(self, request):
        self.data_service.send_notifications()
        return Response({"message": "Notifications sent successfully"}, status=status.HTTP_200_OK)
